# Verksamhetsmarknaden v6 — backend-ansluten startversion

Det här är en kodbas för att färdigställa marknadsplatsen med **Supabase** (auth, databas, bildlagring och behörigheter) och **Stripe Checkout** (riktig betalning). Den är inte driftsatt eller kopplad till dina konton. Sätt aldrig hemliga nycklar i `app.js`.

## Paket och priser

| Paket | Pris | Ingår |
|---|---:|---|
| Basic | 0 kr | Annons i 30 dagar |
| Standard | 69 kr | Bildgalleri och intresseanmälningar |
| Premium | 149 kr | Bättre placering |
| Utvald | 249 kr | Topplacering/extra exponering |

Priserna är i SEK. Betalningsfunktionen använder Stripe Checkout i servermiljö. Betalda annonser ska publiceras först när Stripe-webhooken har verifierat betalningen.

## Funktioner i startversionen

- Supabase Auth-baserad registrering/inloggning och rollprofiler för köpare/säljare/admin.
- Publicerade annonser hämtas från gemensam databas; de är inte bundna till en enskild webbläsare.
- Säljarformulär för att skapa/redigera annonser och ladda upp bilder till Supabase Storage.
- Pausa, återuppta som utkast, radera och förnya annonser.
- Stripe Checkout för Standard/Premium/Utvald, orderhistorik och status från webhook.
- Intresseanmälningar och rapportering av misstänkta annonser.
- Adminvy för rapportgranskning och säljarmarkering/verifiering.
- SQL RLS-policies och separata Edge Functions för känsliga serveråtgärder.
- Grundsidor för integritetspolicy, användarvillkor, cookies och betalningsvillkor.

## Viktigt innan produktion

Det här är en starter som måste konfigureras, testas och säkerhetsgranskas. Den har inte anslutits till dina Supabase-/Stripe-konton. Den ersätter inte juridisk rådgivning. E-postverifiering, återställning av lösenord, kontoradering/export, fullständig kvittohantering och operativ adminrollhantering behöver sättas upp/testas i leverantörernas kontrollpaneler. Lägg inte ut den offentligt med demoannonser eller utan att granska RLS och Edge Functions.

## 1. Skapa Supabase-projekt

1. Skapa projekt i Supabase.
2. Öppna SQL Editor och kör `supabase/migrations/202610100001_initial.sql`.
3. I Authentication → URL Configuration: ange din webbplats som Site URL och lägg till callback/redirect-URL:er.
4. Slå på e-postbekräftelse och konfigurera e-postleverans. Ställ in lösenordsåterställning.
5. I Project Settings → API kopierar du Project URL och `anon`/publishable key till `app.js`.
6. **Lägg aldrig `service_role`-nyckeln eller Stripe secret key i frontend.**

## 2. Edge Functions och hemligheter

Installera Supabase CLI, logga in och länka projektet. Deploya funktionerna:

```bash
supabase functions deploy create-checkout
supabase functions deploy stripe-webhook --no-verify-jwt
supabase functions deploy admin-verify-seller
supabase functions deploy manage-listing
supabase functions deploy publish-free-listing
supabase functions deploy expire-listings
```

Sätt secrets via CLI, inte i Git:

```bash
supabase secrets set STRIPE_SECRET_KEY=sk_test_...
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
supabase secrets set SITE_URL=https://din-domän.se
supabase secrets set CRON_SECRET=ett-långt-slumpat-hemligt-värde
```

Supabase `SUPABASE_URL`, `SUPABASE_ANON_KEY` och `SUPABASE_SERVICE_ROLE_KEY` finns normalt i Edge Function-miljön; kontrollera dem i projektets runtime. Om din miljö inte exponerar dem automatiskt, konfigurera dem som secrets. `service_role` används bara på servern.

## 3. Stripe

1. Skapa Stripe-konto och börja i **testläge**.
2. Aktivera Checkout och fakturakvitton enligt dina behov.
3. Skapa webhook till `https://PROJECT_REF.supabase.co/functions/v1/stripe-webhook`.
4. Lyssna minst på `checkout.session.completed`, `checkout.session.async_payment_failed`, `payment_intent.payment_failed` och `charge.refunded`.
5. Spara webhook-signeringen som `STRIPE_WEBHOOK_SECRET`.
6. Testa med Stripes testkort; växla inte till live innan juridik, återbetalningar, moms och bokföring är granskade.

Webhooken är den auktoritativa publiceringssignalen. **Lita aldrig på `success_url` från webbläsaren** som bevis på betalning.

### Kvitto och orderhistorik

Orderhistorik lagras i databasen. Stripe kan generera kvitto/faktura, men `receipt_url`-fältet behöver kompletteras med ett webhook-flöde som hämtar rätt Charge/Invoice från Stripe och sparar kvittolänken. Detta är markerat i webhookkoden; kontrollera kvittoflödet i testläge innan lansering.

## 4. Administratörskonto

- Skapa ditt konto normalt.
- Promota därefter **enbart via SQL Editor som projektägare**:

```sql
update public.profiles set role='admin' where email='DIN-ADMIN-EMAIL';
```

- Stöd för separata administratörer bör kompletteras med MFA, separat admin-domän/route, granskningslogg och principen minsta behörighet. Ge aldrig användare möjlighet att välja adminroll i registreringsformuläret.
- Testa att en vanlig användare inte kan ändra `role`, `verified_seller`, orders eller rapportstatus.

## 5. Utgång och förnyelse

`expire-listings` måste köras schemalagt, till exempel dagligen via Supabase Cron/pg_cron eller en extern scheduler som skickar `Authorization: Bearer <CRON_SECRET>`. Förnyelse av betalt paket startar en ny Stripe Checkout. Basic förnyas gratis. Kontrollera status efter förnyelse och lägg till e-postpåminnelser före utgång.

## 6. Juridik och integritet

Sidorna `privacy.html`, `terms.html`, `cookies.html` och `payments.html` är mallar, inte färdig juridisk rådgivning. Anpassa företagsuppgifter, kontaktväg, lagringstider, personuppgiftsbiträden, rättslig grund, cookies/analytics, ångerrätt/undantag, reklamation, återbetalning, moms och fakturakrav. Använd inte icke-nödvändiga cookies innan giltigt samtycke. Lägg till självbetjäning för registerutdrag/export/radering och rutiner för personuppgiftsincidenter.

## 7. Bildredigering

Bilder laddas upp permanent till Supabase Storage och länkas till annonsen. Denna startversion erbjuder uppladdning/byte av omslagsbild. Beskärning/rotation före uppladdning kan byggas vidare med en klientbaserad editor; behåll originalet om du behöver återställa. Filstorlek begränsas till 8 MB och accepterade format är JPG, PNG och WebP.

## 8. Lokal förhandsvisning

Öppna `index.html` via en lokal server (inte bara dubbelklick om webbläsaren blockerar resurser). Innan Supabase-konfiguration visas tre tydligt exempelbaserade demoannonser, men autentisering, publicering och betalning är avstängda. Lägg inte ut demoannonser som om de vore riktiga.
