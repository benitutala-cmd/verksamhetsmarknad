import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
Deno.serve(async req=>{
 const auth=req.headers.get("Authorization");const expected=`Bearer ${Deno.env.get("CRON_SECRET")}`;
 if(!auth||auth!==expected)return new Response("Unauthorized",{status:401});
 const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
 const {data,error}=await admin.from("listings").update({status:"expired"}).eq("status","published").lt("expires_at",new Date().toISOString()).select("id");
 if(error)return new Response(error.message,{status:500});
 return Response.json({expired:data?.length||0});
});