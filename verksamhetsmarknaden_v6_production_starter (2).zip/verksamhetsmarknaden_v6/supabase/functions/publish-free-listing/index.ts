import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 try{
  const auth=req.headers.get("Authorization");if(!auth)throw new Error("Du måste logga in.");
  const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await supabase.auth.getUser();if(!user)throw new Error("Ogiltig session.");
  const {listing_id,renew}=await req.json();
  const {data:listing,error}=await supabase.from("listings").select("id,seller_id,package_key").eq("id",listing_id).single();
  if(error||!listing||listing.seller_id!==user.id)throw new Error("Annonsen finns inte.");
  if(listing.package_key!=="basic")throw new Error("Endast Basic kan publiceras utan betalning.");
  const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const now=new Date();
  const {error:upErr}=await admin.from("listings").update({status:"published",published_at:now.toISOString(),expires_at:new Date(now.getTime()+30*86400000).toISOString(),featured_rank:4}).eq("id",listing_id).eq("seller_id",user.id);
  if(upErr)throw upErr;
  await admin.from("orders").insert({seller_id:user.id,listing_id,package_key:"basic",amount_sek:0,currency:"sek",status:"paid",paid_at:now.toISOString()});
  return new Response(JSON.stringify({published:true,renewed:!!renew}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e.message||"Kunde inte publicera annons."}),{status:400,headers:{...cors,"Content-Type":"application/json"}});}
});