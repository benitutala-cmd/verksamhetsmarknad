import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14.25.0?target=deno";
const stripe=new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!,{apiVersion:"2023-10-16"});
const cryptoProvider=Stripe.createSubtleCryptoProvider();
Deno.serve(async req=>{
 const signature=req.headers.get("stripe-signature");if(!signature)return new Response("Missing signature",{status:400});
 const raw=await req.text();let event:Stripe.Event;
 try{event=await stripe.webhooks.constructEventAsync(raw,signature,Deno.env.get("STRIPE_WEBHOOK_SECRET")!,undefined,cryptoProvider);}
 catch(e){return new Response(`Webhook signature error: ${e.message}`,{status:400});}
 const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
 try{
  if(event.type==="checkout.session.completed"){
   const session=event.data.object as Stripe.Checkout.Session;
   if(session.payment_status!=="paid")return new Response("Not paid",{status:200});
   const orderId=session.metadata?.order_id, listingId=session.metadata?.listing_id, packageKey=session.metadata?.package_key;
   if(!orderId||!listingId||!packageKey)throw new Error("Missing checkout metadata");
   const paymentIntent=typeof session.payment_intent==="string"?session.payment_intent:null;
   const chargeReceipt= session.invoice?null:null; // Stripe invoice receipt is linked after invoice/charge retrieval if enabled.
   const {error:oe}=await admin.from("orders").update({status:"paid",stripe_payment_intent_id:paymentIntent,paid_at:new Date().toISOString()}).eq("id",orderId).eq("status","pending");
   if(oe)throw oe;
   const rank:Record<string,number>={standard:3,premium:2,featured:1,basic:4};
   const {error:le}=await admin.from("listings").update({status:"published",package_key:packageKey,featured_rank:rank[packageKey]??4,published_at:new Date().toISOString(),expires_at:new Date(Date.now()+30*24*60*60*1000).toISOString()}).eq("id",listingId);
   if(le)throw le;
   // Receipt URL can be added by a follow-up invoice/charge webhook after retrieving the Stripe invoice or charge.
  }else if(event.type==="checkout.session.async_payment_failed"||event.type==="payment_intent.payment_failed"){
   const obj=event.data.object as any;const orderId=obj.metadata?.order_id;
   if(orderId)await admin.from("orders").update({status:"failed"}).eq("id",orderId);
  }else if(event.type==="charge.refunded"){
   const charge=event.data.object as Stripe.Charge;
   if(charge.payment_intent){await admin.from("orders").update({status:"refunded"}).eq("stripe_payment_intent_id",String(charge.payment_intent));}
  }
  return new Response("ok",{status:200});
 }catch(e){console.error("stripe-webhook processing error",e);return new Response("Webhook processing failed",{status:500});}
});