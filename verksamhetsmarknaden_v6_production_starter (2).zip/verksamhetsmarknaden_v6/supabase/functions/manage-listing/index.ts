import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 try{
  const auth=req.headers.get("Authorization");if(!auth)throw new Error("Du måste logga in.");
  const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await supabase.auth.getUser();if(!user)throw new Error("Ogiltig session.");
  const {listing_id,action}=await req.json();
  const {data:listing,error}=await supabase.from("listings").select("id,seller_id,status").eq("id",listing_id).single();
  if(error||!listing||listing.seller_id!==user.id)throw new Error("Annonsen finns inte eller tillhör inte ditt konto.");
  let status:string;
  if(action==="pause"&&listing.status==="published")status="paused";
  else if(action==="resume"&&["paused","expired"].includes(listing.status))status="draft";
  else throw new Error("Ogiltig statusändring.");
  const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const {error:upErr}=await admin.from("listings").update({status}).eq("id",listing_id).eq("seller_id",user.id);
  if(upErr)throw upErr;
  return new Response(JSON.stringify({status}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e.message||"Kunde inte ändra annons."}),{status:400,headers:{...cors,"Content-Type":"application/json"}});}
});