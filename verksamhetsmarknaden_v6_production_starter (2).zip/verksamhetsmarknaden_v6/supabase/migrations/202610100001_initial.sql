-- Verksamhetsmarknaden production starter schema.
-- Review before production. Supabase Auth handles password storage; never store passwords yourself.
create extension if not exists pgcrypto;

create type public.account_role as enum ('buyer','seller','admin');
create type public.listing_status as enum ('draft','pending_payment','published','paused','expired','rejected');
create type public.order_status as enum ('pending','paid','failed','refunded');
create type public.report_status as enum ('new','reviewing','resolved','dismissed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  business_name text,
  org_number text,
  role public.account_role not null default 'buyer',
  verified_seller boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 100),
  category text not null,
  city text not null,
  asking_price bigint not null check (asking_price >= 0),
  revenue bigint check (revenue is null or revenue >= 0),
  description text not null check (char_length(description) between 10 and 5000),
  image_path text,
  image_url text,
  package_key text not null default 'basic' check (package_key in ('basic','standard','premium','featured')),
  status public.listing_status not null default 'draft',
  verified_seller boolean not null default false,
  featured_rank int not null default 100,
  published_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index listings_public_idx on public.listings(status, expires_at, featured_rank, published_at desc);
create index listings_seller_idx on public.listings(seller_id, created_at desc);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete restrict,
  listing_id uuid not null references public.listings(id) on delete restrict,
  package_key text not null check (package_key in ('standard','premium','featured','basic')),
  amount_sek integer not null check (amount_sek >= 0),
  currency text not null default 'sek',
  status public.order_status not null default 'pending',
  stripe_checkout_session_id text unique,
  stripe_payment_intent_id text,
  stripe_invoice_id text,
  receipt_url text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index orders_seller_idx on public.orders(seller_id,created_at desc);

create table public.interests (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  message text not null check (char_length(message) between 1 and 2000),
  status text not null default 'new' check (status in ('new','contacted','closed')),
  created_at timestamptz not null default now(),
  unique(listing_id,buyer_id)
);
create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,listing_id)
);
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  reporter_id uuid references public.profiles(id) on delete set null,
  reason text not null,
  details text,
  status public.report_status not null default 'new',
  reviewed_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_table text not null,
  target_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin') $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Role is assigned server-side from metadata only for buyer/seller. Admin must be promoted manually by trusted operator.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare requested text;
begin
  requested := coalesce(new.raw_user_meta_data->>'requested_role','buyer');
  if requested not in ('buyer','seller') then requested := 'buyer'; end if;
  insert into public.profiles(id,email,full_name,role)
  values(new.id,new.email,left(new.raw_user_meta_data->>'full_name',100),requested::public.account_role)
  on conflict(id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.orders enable row level security;
alter table public.interests enable row level security;
alter table public.favorites enable row level security;
alter table public.reports enable row level security;
alter table public.audit_log enable row level security;

create policy "Public can view published active listings" on public.listings for select to anon,authenticated
using (status='published' and expires_at > now() or seller_id=auth.uid() or public.is_admin());
create policy "Seller can create own listings" on public.listings for insert to authenticated
with check (seller_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.role in ('seller','admin')));
-- Only editable content/package columns are client-updatable. Status, expiry and placement are server-controlled.
revoke update on public.listings from authenticated;
grant update(title,category,city,asking_price,revenue,description,image_path,image_url,package_key) on public.listings to authenticated;
create policy "Seller can update own listings" on public.listings for update to authenticated
using (seller_id=auth.uid() or public.is_admin()) with check (seller_id=auth.uid() or public.is_admin());
create policy "Seller/admin can delete own listings" on public.listings for delete to authenticated
using (seller_id=auth.uid() or public.is_admin());

create policy "Read own profile or admin" on public.profiles for select to authenticated using (id=auth.uid() or public.is_admin());
create policy "Update own profile limited by app" on public.profiles for update to authenticated using (id=auth.uid() or public.is_admin()) with check (id=auth.uid() or public.is_admin());
-- Protect role and verified_seller from self-promotion using column grants. Admin uses service role/admin server operations.
revoke update on public.profiles from authenticated;
grant update(full_name,business_name,org_number) on public.profiles to authenticated;

create policy "Users can view own orders" on public.orders for select to authenticated using (seller_id=auth.uid() or public.is_admin());
create policy "Users can view relevant interests" on public.interests for select to authenticated using (buyer_id=auth.uid() or exists(select 1 from public.listings l where l.id=listing_id and l.seller_id=auth.uid()) or public.is_admin());
create policy "Buyers can create own interests" on public.interests for insert to authenticated with check (buyer_id=auth.uid() and exists(select 1 from public.listings l where l.id=listing_id and l.status='published' and l.seller_id<>auth.uid()));
create policy "Buyer can manage own favorites" on public.favorites for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "Anyone can submit a report" on public.reports for insert to anon,authenticated with check (reporter_id is null or reporter_id=auth.uid());
create policy "Admins can view/update reports" on public.reports for select to authenticated using (public.is_admin());
create policy "Admins can update reports" on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins can read audit log" on public.audit_log for select to authenticated using (public.is_admin());

-- Storage bucket. Run this migration in Supabase SQL editor; public read is for public listing images only.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('listing-images','listing-images',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict(id) do nothing;
create policy "Public can view listing images" on storage.objects for select to anon,authenticated using (bucket_id='listing-images');
create policy "Seller uploads into own folder" on storage.objects for insert to authenticated
with check (bucket_id='listing-images' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Seller updates own images" on storage.objects for update to authenticated
using (bucket_id='listing-images' and (storage.foldername(name))[1]=auth.uid()::text)
with check (bucket_id='listing-images' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Seller deletes own images" on storage.objects for delete to authenticated
using (bucket_id='listing-images' and (storage.foldername(name))[1]=auth.uid()::text);

-- Note: service-role Edge Functions handle paid publication, orders, receipt URLs and expiry.
