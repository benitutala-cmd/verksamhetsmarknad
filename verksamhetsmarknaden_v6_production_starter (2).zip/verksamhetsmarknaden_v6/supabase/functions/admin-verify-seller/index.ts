import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 try{
  const auth=req.headers.get("Authorization");if(!auth)throw new Error("Du måste logga in.");
  const userClient=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:auth}}});
  const {data:{user}}=await userClient.auth.getUser();if(!user)throw new Error("Ogiltig session.");
  const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const {data:actor}=await admin.from("profiles").select("role").eq("id",user.id).single();
  if(actor?.role!=="admin")throw new Error("Endast administratörer får verifiera säljare.");
  const {profile_id,verified}=await req.json();
  if(typeof profile_id!=="string"||typeof verified!=="boolean")throw new Error("Ogiltig begäran.");
  const {error}=await admin.from("profiles").update({verified_seller:verified}).eq("id",profile_id);
  if(error)throw error;
  await admin.from("audit_log").insert({actor_id:user.id,action:verified?"seller_verified":"seller_unverified",target_table:"profiles",target_id:profile_id});
  return new Response(JSON.stringify({ok:true}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e.message||"Kunde inte uppdatera verifiering."}),{status:400,headers:{...cors,"Content-Type":"application/json"}});}
});