import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14.25.0?target=deno";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
const prices:Record<string,number>={standard:6900,premium:14900,featured:24900}; // amounts in öre: 69, 149, 249 SEK
Deno.serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 try{
  const auth=req.headers.get("Authorization"); if(!auth)throw new Error("Du måste logga in.");
  const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:auth}}});
  const {data:{user},error:authError}=await supabase.auth.getUser();if(authError||!user)throw new Error("Ogiltig session.");
  const body=await req.json();const listing_id=String(body.listing_id||"");const package_key=String(body.package_key||"");
  if(!(package_key in prices))throw new Error("Okänt eller kostnadsfritt paket.");
  const {data:listing,error}=await supabase.from("listings").select("id,seller_id,title,package_key,status").eq("id",listing_id).single();
  if(error||!listing||listing.seller_id!==user.id)throw new Error("Annonsen finns inte eller tillhör inte ditt konto.");
  if(listing.package_key!==package_key)throw new Error("Paketet matchar inte annonsen. Spara annonsen igen.");
  const stripe=new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!,{apiVersion:"2023-10-16"});
  const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const orderId=crypto.randomUUID();
  const amount=prices[package_key]/100;
  const {error:orderError}=await admin.from("orders").insert({id:orderId,seller_id:user.id,listing_id,package_key,amount_sek:amount,currency:"sek",status:"pending"});
  if(orderError)throw orderError;
  const origin=Deno.env.get("SITE_URL")!;
  const session=await stripe.checkout.sessions.create({
   mode:"payment",payment_method_types:["card"],customer_email:user.email,
   line_items:[{price_data:{currency:"sek",unit_amount:prices[package_key],product_data:{name:`Verksamhetsmarknaden — ${package_key}`,description:`Annons: ${listing.title} (30 dagar)`}},quantity:1}],
   metadata:{order_id:orderId,listing_id,seller_id:user.id,package_key},
   success_url:`${origin}/?payment=success&session_id={CHECKOUT_SESSION_ID}`,
   cancel_url:`${origin}/?payment=cancelled`,
   invoice_creation:{enabled:true}
  });
  await admin.from("orders").update({stripe_checkout_session_id:session.id}).eq("id",orderId);
  await admin.from("listings").update({status:"pending_payment"}).eq("id",listing_id);
  return new Response(JSON.stringify({url:session.url}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e.message||"Kunde inte starta checkout."}),{status:400,headers:{...cors,"Content-Type":"application/json"}});}
});